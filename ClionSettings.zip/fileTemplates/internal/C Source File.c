#parse("C File Header.h")
#if (${HEADER_FILENAME})
#[[#include]]# "${HEADER_FILENAME}"
#end
#[[#include <bits/stdc++.h>]]#
 
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
 
#[[#ifndef OVO_]]#
#[[#define cerr if (false) cerr]]#
#[[#endif]]#
 
int main() {
#[[#ifdef OVO_]]#
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    freopen("debug.txt", "w", stderr);
#[[#else]]#
    ios_base::sync_with_stdio(false);
    cin.tie();
#[[#endif]]#
}